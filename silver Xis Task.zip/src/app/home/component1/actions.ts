export const actions: any = [   
    {
        value: '',
        attributes: '',
        key: '000'
    },
    {
        value: 'Assemble',
        attributes: '',
        key: '001'
    },
    {
        value: 'Cleaning',
        attributes: '',
        key: '002'
    },
    {
        value: 'DER',
        attributes: '',
        key: '003'
    },
    {
        value: 'Disassemble',
        attributes: '',
        key: '004'
    },{
        value: 'Evaluate',
        attributes: '',
        key: '005'
    },

    {
        value: 'Inspect',
        attributes: '',
        key: '006'
    },
    {
        value: 'Part Out',
        attributes: '',
        key: '007'
    },
    {
        value: 'QC',
        attributes: '',
        key: '008'
    },
    {
        value: 'Receive',
        attributes: '',
        key: '009'
    },
    {
        value: 'Shipping',
        attributes: '',
        key: '010'
    },
    {
        value: 'Teardown',
        attributes: '',
        key: '011'
    },
    {
        value: 'Test',
        attributes: '',
        key: '012'
    },
    
]