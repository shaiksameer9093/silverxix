import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Component1Component } from './component1/component1.component';
import { Component2Component } from './component2/component2.component';
import { Component3Component } from './component3/component3.component';
import { Routes, RouterModule } from '@angular/router';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { FormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import {DropdownModule} from 'primeng/dropdown';


const routes: Routes = [
  {
      path: '',
      component: Component1Component,
      children: [
         {
            path: '',
            redirectTo: 'home',
            pathMatch: 'full'
          }
      ]
  }
];
@NgModule({
  declarations: [Component1Component, Component2Component, Component3Component],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    NgMultiSelectDropDownModule.forRoot(),
    FormsModule,
    TableModule,
    DropdownModule
  ]
})
export class HomeModule { }
