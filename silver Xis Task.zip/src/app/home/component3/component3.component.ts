import { Component, OnInit, ViewChild } from '@angular/core';
import { LazyLoadEvent, DataTable } from 'primeng/primeng';
import {SelectItem} from 'primeng/api';

@Component({
  selector: 'app-component3',
  templateUrl: './component3.component.html',
  styleUrls: ['./component3.component.scss']
})
export class Component3Component implements OnInit {
  @ViewChild('dt',{static:true}) public dataTable: DataTable;
  cities: SelectItem[];
  //data values
  itemNumber:any;
  description:any;
  selectedOption:any;
  Qty:number;
  // static onject row Rendering
  public rowData = [{"name": "itemNumber1"}]
  itemsdata = ['Consume','test','kit','Para']
  constructor() { }

  ngOnInit() {}
  saveWarkflow(){
   const item1 =  this.itemNumber;
   const item2 = this.description;
   const item3 = this.selectedOption;
   console.log(this.selectedOption,'val')
   const item4 = this.Qty;
   if(item1 || item2 || item3 || item4 !== null){
    alert (JSON.stringify(item1 + item2 + item3 + item4));
   }
  }
  onRowDeleteItem(){
    this.rowData = [];
  }
  addTablerow(){
     this.rowData.push({"name": "itemNumber2"})
  }
}
