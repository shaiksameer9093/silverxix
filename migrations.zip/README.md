#Dev Branch

#---------------- 0. Db Migrations Steps ------------------ 
- To create a migration script
    node node_modules\db-migrate\bin\db-migrate create school_schooltypes
- To update database from migration scripts 
- To undo recent database migration executed 
- 

#------------------- 1. To run backend in debug mode --------------------
Step 1: Open server.ts
Step 2: Goto Debug (Ctrl+Shift+D) mode in Visual Studio Code
Step 3: Click on Start Debugging button (Play button at the top of explorer window)
Step 4: Put break points in your code and wait
