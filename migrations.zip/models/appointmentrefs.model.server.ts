import MainDb from "../configs/sqls";
const Sequelize = require('sequelize');

const AppointmentsRef = MainDb.define('appointmentsref', {
  id: { type: Sequelize.INTEGER, autoIncrement: true, primaryKey: true },
  appointmentId: { type: Sequelize.INTEGER, allowNull: false },
  consultantNotes: { type: Sequelize.TEXT, allowNull: false },
  chatNotes: { type: Sequelize.STRING, allowNull: false }
}, { timestamps: false });

// defaultValue: Sequelize.NOW
export default AppointmentsRef;