import MainDb from "../configs/sqls";
const Sequelize = require('sequelize');

const UserRole = MainDb.define('userroles', {
  id: { type: Sequelize.INTEGER, autoIncrement: true, primaryKey: true },
  userId: { type: Sequelize.INTEGER, allowNull: false },
  roleId: { type: Sequelize.INTEGER, allowNull: false },
  created_on: { type: Sequelize.DATEONLY, allowNull: false },
  updated_on: { type: Sequelize.DATEONLY, allowNull: false }
}, { timestamps: false });

// defaultValue: Sequelize.NOW
export default UserRole;