import MainDb from "../configs/sqls";
const Sequelize = require('sequelize');

const Role = MainDb.define('role', {
  id: { type: Sequelize.INTEGER, autoIncrement: true, primaryKey: true },
  roleName: { type: Sequelize.INTEGER, allowNull: false },
  createdOn: { type: Sequelize.DATE, allowNull: true },
  updatedOn: { type: Sequelize.DATE, allowNull: true }
}, { timestamps: false });

// defaultValue: Sequelize.NOW
export default Role;