import MainDb from "../configs/sqls";
const Sequelize = require('sequelize');

const AppointmentType = MainDb.define('appointmenttype', {
  id: { type: Sequelize.INTEGER, autoIncrement: true, primaryKey: true },
  typeName: { type: Sequelize.STRING, allowNull: false }
}, { timestamps: false });

// defaultValue: Sequelize.NOW
export default AppointmentType;