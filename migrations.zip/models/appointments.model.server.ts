import MainDb from "../configs/sqls";
const Sequelize = require('sequelize');

const Appointment = MainDb.define('appointment', {
  id: { type: Sequelize.INTEGER, autoIncrement: true, primaryKey: true },
  userId: { type: Sequelize.INTEGER, allowNull: false },
  petId: { type: Sequelize.INTEGER, allowNull: false },
  bookingId: { type: Sequelize.INTEGER, allowNull: false },
  appointmentDate: { type: Sequelize.DATEONLY, allowNull: false },
  slot: { type: Sequelize.STRING, allowNull: false },
  appointmentTypeId: { type: Sequelize.STRING, allowNull: false },
  paymentId: { type: Sequelize.STRING, allowNull: false },
  status: { type: Sequelize.STRING, allowNull: false },
  userRating: { type: Sequelize.FLOAT, allowNull: true },
  practiceRating: { type: Sequelize.FLOAT, allowNull: true },
  createdOn: { type: Sequelize.DATE, allowNull: true }
}, { timestamps: false });

// defaultValue: Sequelize.NOW
export default Appointment;