import MainDb from "../configs/sqls";
const Sequelize = require('sequelize');

const User = MainDb.define('users', {
  id: { type: Sequelize.INTEGER, autoIncrement: true, primaryKey: true },
  firstName: { type: Sequelize.STRING, allowNull: false },
  lastName: { type: Sequelize.STRING, allowNull: true },
  email: { type: Sequelize.STRING, allowNull: false },
  mobile: { type: Sequelize.INTEGER, allowNull: false },
  password: { type: Sequelize.STRING, allowNull: false },
  profilePic: { type: Sequelize.STRING, allowNull: true },
  gender: { type: Sequelize.STRING, allowNull: false },
  isactive: { type: Sequelize.BOOLEAN, allowNull: true },
  lastAccessOn: { type: Sequelize.DATE, allowNull: true },
  createdOn: { type: Sequelize.DATE, allowNull: true }
}, { timestamps: false });

// defaultValue: Sequelize.NOW
export default User;