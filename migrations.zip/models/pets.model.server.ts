import MainDb from "../configs/sqls";
const Sequelize = require('sequelize');

const Pet = MainDb.define('pet', {
  id: { type: Sequelize.INTEGER, autoIncrement: true, primaryKey: true },
  userId: { type: Sequelize.INTEGER, allowNull: false },
  petName: { type: Sequelize.STRING, allowNull: false },
  breed: { type: Sequelize.STRING, allowNull: false },
  species: { type: Sequelize.STRING, allowNull: false },
  gender: { type: Sequelize.STRING, allowNull: false },
  dob: { type: Sequelize.DATEONLY, allowNull: true },
  profilePic: { type: Sequelize.STRING, allowNull: true },
  updatedOn: { type: Sequelize.DATE, allowNull: true },
  createdOn: { type: Sequelize.DATE, allowNull: true }
}, { timestamps: false });

// defaultValue: Sequelize.NOW
export default Pet;