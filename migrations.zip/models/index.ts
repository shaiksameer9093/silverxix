/*
Barrel module configuration, to group model definitions to sync with Db and app
*/
export { default as User } from './users.model.server';
export { default as AppointmentsRef} from './appointmentrefs.model.server';
export { default as Appointment} from './appointments.model.server';
export { default as AppointmentType} from './appointmenttypes.model.server';
export { default as Pet} from './pets.model.server';
export { default as Role} from './roles.model.server';
export { default as UserRole} from './userroles.model.server';
export { default as UserStatus} from './userstatus.model.server'

/*
Associations between the models, which automatically add foreign key constraints
in Db schema.
*/

import Users from './users.model.server';
import AppointmentsRef from './appointmentrefs.model.server';
import Appointments from './appointments.model.server';
import AppointmentTypes from './appointmenttypes.model.server';
import Pets from './pets.model.server';
import Roles from './roles.model.server';
import UserRole from './userroles.model.server';
import UserStatus from './userstatus.model.server';


Users.hasMany(Pets);
