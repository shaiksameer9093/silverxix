import MainDb from "../configs/sqls";
const Sequelize = require('sequelize');

const UserStatus = MainDb.define('userstatu', {
id: { type: Sequelize.INTEGER, autoIncrement: true, primaryKey: true },
userId: { type: Sequelize.INTEGER, allowNull: false },
verified: { type: Sequelize.BOOLEAN, allowNull: true },
verifiedOn: { type: Sequelize.DATE, allowNull: true }
}, { timestamps: false });

// defaultValue: Sequelize.NOW
export default UserStatus;