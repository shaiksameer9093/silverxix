// ------ controllers import
import { Controller } from '../controllers/auth.controller.server';

export default class AuthRoutes {

    constructor(app: any) {
       this.setupRoutes(app);
    }

    // ------- setting up required api's list
      private setupRoutes(app: any) {
        app.post('/randomToken', Controller.getRandomToken);
        app.post('/loginChecker', Controller.loginChecker);
        app.post('/signIn', Controller.login);
        app.post('/registration', Controller.registration);
        app.post('/verifyOTP', Controller.verifyOTP);
        app.post('/forgotPassword', Controller.forgotPassword);
        app.post('/resetPassword', Controller.resetPassword);
        app.get('/getCaptcha', Controller.getCaptcha);
        app.post('/resendOTP', Controller.resendOTP);
        app.post('/otpCheck', Controller.otpCheck);
     }
}