// ------ controllers import
import { Controller } from '../controllers/user.controller.server';

export default class UsersRoutes {

    constructor(app: any) {
       this.setupRoutes(app);
    }

    // ------- setting up required api's list
    private setupRoutes(app: any) {
        app.get('/getByUserId/:id', Controller.getUser);
    }
}