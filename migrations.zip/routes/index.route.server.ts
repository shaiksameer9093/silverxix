// index.route.server.js
import controller from '../controllers/index.controller.server';

export default class HomeRoutes {
   constructor(app: any) {
      this.setupRoutes(app);
   }
   // define the default route (Path -> '/')
   private setupRoutes(app: any) {
      app.get('/', controller.render);
   }
}
