import controller from '../controllers/userroles.controller.server';
import {UserRole} from '../models';

export default class UserrolesRoutes {
   constructor(app: any) {
      this.setupRoutes(app);
   }
   // define the default route (Path -> '/')
   private setupRoutes(app: any) {
     app.get('/',controller.get)
   }
}