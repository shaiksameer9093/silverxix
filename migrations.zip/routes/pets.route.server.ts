// ------ controllers import
import Controller from '../controllers/pets.controller.server';

export default class PetRoutes {

    constructor(app: any) {
        this.setupRoutes(app);
    }

    // ------- setting up required api's list
    private setupRoutes(app: any) {
        app.post('/addpet', Controller.addPet);
        app.get('/petlist/:userId', Controller.getPetList);
        app.put('/editpet/:petId', Controller.editPet);
        app.delete('/delete/:petId', Controller.deletePet);
    }
}