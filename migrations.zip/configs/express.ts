// load modules
import * as express from 'express';
import * as morgan from 'morgan';
import * as session from 'express-session';
import * as bodyParser from 'body-parser'
const cron = require("node-cron");
const helmet = require('helmet');
const configuration = require(`./env/${process.env.MEAN_ENV}`);

// controller imports
import configsController from '../controllers/configs.controller.server';
import Authentication from '../controllers/middleware/authentication.middleware.server';
// Routes imports
import HomeRoutes from '../routes/index.route.server';
import UserrolesRoutes from '../routes/userroles.route.server';
import AuthRoutes from '../routes/auth.route.server';
import PetRoutes from '../routes/pets.route.server';
import UsersRoutes from '../routes/user.route.server';


class App {
   public app: any;
   private cronTask: any;

   constructor() {
      this.app = express();
      this.config();
      this.routes();
      // initialize the env with default db records.
      this.init();
   }

   private config(): void {
      // configure middlewares
      // --------- to generate log information
      if (process.env.MEAN_ENV === 'development') {
         this.app.use(morgan('dev'));
      }
      // ------- to protect your app from some well-known web vulnerabilities by setting 
      // ------- HTTP headers appropriately.
      this.app.use(helmet());
      // to avoid revealing Tech stack through header
      this.app.disable('x-powered-by');

      // --------- request content parser
      // this.app.use(bodyParser.urlencoded({ extended: true }));
      this.app.use(bodyParser.json({ limit: '100mb' }));
      // this.app.use(multer({storage: storage}).single('banner'));
      // --------- session support
      this.app.use(session({
         secret: configuration.sessionSecret
         , resave: true
         , saveUninitialized: true
      }));

      // -------- CORS configuration
      // this.app.use(cors());
      // this.app.options('/signup', cors());
      this.app.use(function (req, resp, next) {
         resp.setHeader('Access-Control-Allow-Origin',
            '*');
         resp.setHeader('Access-Control-Allow-Methods',
            'OPTIONS, GET, POST, PUT, DELETE');
         resp.setHeader('Access-Control-Allow-Headers',
            'application/json, X-Requested-With,application/x-www-form-urlencoded, image/png, Content-Type, Authorization, Origin, Accept, multipart/form-data , application/octet-stream');
         resp.setHeader('Access-Control-Expose-Headers', 'Content-Disposition');
         next();
      });
      // configure request token verifiation middleware
      // this.app.use(Authentication.decodeAuthToken);

      // -------- to serve static resoc and includes
      this.app.use(express.static('./public'));

   }

   private routes(): void {
      // initialise and configure routes against app instance
      new AuthRoutes(this.app);
      new HomeRoutes(this.app);
      new UsersRoutes(this.app);
      new UserrolesRoutes(this.app);
      new PetRoutes(this.app);
   }

   public init(): void {
      configsController.init((err) => {
         if (err) {
            console.log('Failed to initialize environment please restart!\nError:' + err.message);
            return;
         }
         console.log('App ready!');
      });
   }

   public listen(port: number, fn: any): void {
      // this.app.listen(port, fn); // without socket.io only for express app
      this.app.listen(port, fn); // with socket.io and express app
   }

   public close() {
     
      this.app.close(() => {     // stopping http server
         console.log('Http server closed.');
         process.exit(0);        // stop the server process
      });
   }
}
const app = new App();

export default app;
