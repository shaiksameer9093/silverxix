class DevConfig {
    public get sessionSecret(): string { return 'the_vet_session_secret'; }
    // public get secretKey(): string { return 'Q09NUExVUyBTRUNSRVQgS2V5'; }
    public get secretKey(): string { return '0ED7E366D006949930A538DF72A83E5380B936B872B9D2AB5D0450EFCA6B3B54'; }

    public get dbConfig(): any {
        return {
            host: '54.72.44.236',
            database: 'smvDb',
            username: 'smvuser',
            password: 'pSEk[+U~[Qu7&^',
            dialect: 'mysql',
            multipleStatements: true,
            logging: true
        };
    }

    public get mailConfig(): any {
        return {
            from: "info@emembler.com",
            auth: {
                service: 'Gmail',
                auth: {
                    user: 'info@emembler.com',
                    pass: 'American99!'
                }
            }
        }
    }
}
const devConfig = new DevConfig();
module.exports = devConfig;
