class UATConfig {
    public get sessionSecret(): string { return ''; }
    // public get secretKey(): string { return 'Q09NUExVUyBTRUNSRVQgS2V5'; }
    public get secretKey(): string { return ''; }

    public get dbConfig(): any {
        return {
            host: '',
            database: '',
            username: '',
            password: '',
            dialect: 'mysql',
            multipleStatements: true,
            logging: true
        };
    }

    public get mailConfig(): any {
        return {
            from: "",
            auth: {
                service: 'Gmail',
                auth: {
                    user: '',
                    pass: ''
                }
            }
        }
    }
}
const uatConfig = new UATConfig();
module.exports = uatConfig;
