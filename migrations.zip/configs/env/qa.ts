class QAConfig {
    public get sessionSecret(): string { return ''; }
    public get secretKey(): string { return ''; }

    public get dbConfig(): any {
        return {
            host: '54.72.44.236',
            database: 'smvDb_QA',
            username: 'smvuser',
            password: 'pSEk[+U~[Qu7&^',
            dialect: 'mysql',
            multipleStatements: true,
            logging: true
        };
    }
    public get mailConfig(): any {
        return {
            from: "",
            auth: {
                service: 'Gmail',
                auth: {
                    user: '',
                    pass: ''
                }
            }
        }
    }
}
const qaConfig = new QAConfig();
module.exports = qaConfig;
