// load modules
import { Request, Response, NextFunction } from 'express';
import MainDb from '../configs/sqls';
const Sequelize = require('sequelize'), op = Sequelize.Op;

// --------- import middleware controllers
import * as CommonMiddleware from './middleware/common.middleware.server';
import AuthenticationMiddleware from '../controllers/middleware/authentication.middleware.server';
import Mailer from '../controllers/middleware/mailer.server';

// ------ import models
import Users from '../models/users.model.server';

class UserController {
    constructor() {}

    /**
     * getUser - for get a single user by id
     * @param req - user id request in queryString id
     */
    public getUser(req: Request, res: Response) {
        let userId = req.query.id;
        Users.findOne({
            where: { id: userId }
        }).then(user => {
            if (user) {
                user.password = '';
                res.json({ status: 200, data: user});
            } else {
                res.json({ status: 500, message: 'User does not exist, for the user id' });
            }
        }, err => {
            res.json({ status: 500, message: err });
        });
    }
}

export const Controller = new UserController();

