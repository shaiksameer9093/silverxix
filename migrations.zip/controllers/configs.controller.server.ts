import MainDb from "../configs/sqls";
const fs = require('fs');

class ConfigsController {
    static INIT_STATUS = false;
    static CONFIG_RECORDS = `[]`;

    public init(fn: any) {
        if (ConfigsController.INIT_STATUS === true) return;


        MainDb
            .authenticate()
            .then(() => {
                console.log('Connection has been established successfully.');
                // MainDb.sync().then(() => {

                //     console.log('Db Synch completed!');
                //     fn();
                // });
            })
            .catch(err => {
                console.error('Unable to connect to the database:', err);
            });

   
    }
}

const controller = new ConfigsController();
export default controller;