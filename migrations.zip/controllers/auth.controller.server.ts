// load modules
import { Request, Response, NextFunction } from 'express';
import DefaultConstant from '../controllers/middleware/constants.middleware.server';
import * as moment from 'moment';
import MainDb from '../configs/sqls';
const captchapng = require('captchapng');
const Sequelize = require('sequelize'), op = Sequelize.Op;

// --------- import middleware controllers
import * as CommonMiddleware from './middleware/common.middleware.server';
import AuthenticationMiddleware from '../controllers/middleware/authentication.middleware.server';
import Mailer from '../controllers/middleware/mailer.server';

// twillio client initialize for SMS notification
const twillioClient = require('twilio')(DefaultConstant.TWILLIO_ACCOUNTSID,
    DefaultConstant.TWILLIO_AUTHTOKEN);

// ------ import models
import Users from '../models/users.model.server';
import UserStatus from '../models/userstatus.model.server';

class AuthController {

    constructor() { }
    // ---------------------- Start of request handlers

    /**
     * generate random token
     */
    public getRandomToken(req: Request, resp: Response) {
        resp.json({
            status: 200, token: AuthenticationMiddleware.encodeAuthToken(
                CommonMiddleware.generateRandomNumber(), 2)
        })
    }

    /**
     * loginChecker - to send the encrypted password using random salt
     * @param req - will contain body - email
     * @param resp - with set header x-request-id - generate random salt
     */
    public loginChecker(req: Request, resp: Response): any {
        let paraData = req.body;
        if (paraData) {
            // verify user existance
            Users.findOne({
                attributes: ['password', 'isactive'],
                where: { email: paraData.email }
            }).then(user => {
                if (user) {
                    // user isactive - true
                    if (user.isactive) {
                        let decrypted_password = '';
                        try {
                            // random salt and encrypted password
                            decrypted_password = AuthenticationMiddleware.passwordDecrypt(user.password);
                            const randSecret = CommonMiddleware.getRandomSalt();
                            const ePwd = AuthenticationMiddleware.passwordEncrypt(decrypted_password, randSecret);
                            resp.json({ status: 200, secretSalt: randSecret, data: ePwd.toString() });
                        } catch (ex) {
                            console.log('Error:' + ex.message);
                            resp.json({ status: 123, error: '', message: 'Invalid E-mailId or Password !' });
                            return;
                        }
                    } else {
                        resp.json({ status: 146, message: 'Not an Active User!' });
                    }

                } else {
                    resp.json({ status: 500, message: 'Invalid E-mailId or Password !' });
                }
            }, err => {
                console.log('Error:' + err.message);
                resp.json({ status: 500, message: 'Failed to find User details, please retry!' });
            });
        }
    }

    /**
     * login - will verify the encrypted password using email and random salt
     * @param req - will have queryString random salt,
     * body - email, password
     * @param resp 
     */
    public login(req: Request, resp: Response) {
        let paraData = req.body;
        let email = paraData.email;
        let clientEncPwd = paraData.password;
        // const queryString = req.header('q')  // if you are using in postman
        const queryString = req.query.q; 
        // queryString and paraData existence
        if (queryString && paraData) {
            // verify user existance
            Users.findOne({
                where: { email: email }
            }).then(user => {
                // user exist
                if (user) {
                    let idEncode = AuthenticationMiddleware.encodeData(user.id);
                    // user isactive - true
                    if (user.isactive) {
                        let decrypted_password = AuthenticationMiddleware.passwordDecrypt(user.password);
                        let svrEPassword = AuthenticationMiddleware.passwordEncrypt(decrypted_password, queryString);
                        if (clientEncPwd === svrEPassword.toString()) {
                            let jwtToken;
                            // verify the remember me
                            if (req.body.isChecked) {
                                jwtToken = AuthenticationMiddleware.encodeAuthToken(idEncode, 1);
                            } else {
                                jwtToken = AuthenticationMiddleware.encodeAuthToken(idEncode, 2);
                            }
                            user.password = '';   // dont send password
                            const fResult = { eRsul: user, token: jwtToken };
                            resp.json({ status: 200, message: 'Login success!', data: fResult});
                        } else {
                            resp.json({ status: 500, message: 'Invalid E-mailId or Password !' });
                        }
                    } else {
                        // send OTP to respective email, if user isactive - false
                        AuthController.sendOTPEmailPhone(paraData, (OTP) => {
                            const secretData = {secret: AuthenticationMiddleware.encodeData(OTP),
                                userId: idEncode, email: paraData.email};
                            resp.json({status: 146, message: 'OTP send to respected email',
                            data: AuthenticationMiddleware.encodeAuthToken(secretData)});
                        });
                    }                        
                } else {
                    resp.json({ status: 500, message: 'Invalid credentials or status is not valid!' });
                }
            }, err => {
                console.log('err', err);
                resp.json({ status: 500, message: 'Invalid credentials or status is not valid!' });
            });
        } else {
            resp.json({ status: 500, message: 'Ensure the query string' });
        }
    }

    /**
     * registration
     * @param req - will have the body
     */
    public registration(req: Request, resp: Response) {
        let paraData = req.body;
        // verify the email exists
        // Mailer.mailSend('chethan@lucidatechnologies.com');
        MainDb.query(
            `SELECT U.email FROM users AS U where U.email= '${paraData.email}';`,
            {
                type: Sequelize.QueryTypes.SELECT,
                mapToModel: false,
                raw: true
            }
        ).then((user: any) => {
            if (user.length > 0) {
                resp.json({ status: 500, message: 'User with email already exists' });
            } else {
                paraData.createdOn = new Date().toLocaleDateString(); // updating user created on
                const user = Users.build(paraData); // prepare user using User model
                // saving the user
                user.save().then(U => {
                    let userStatus = UserStatus.build({userId: U.id});
                    userStatus.save().then(US => {
                        let idEncode = AuthenticationMiddleware.encodeData(U.id);
                        // send OTP to respective email, if user isactive - false
                        AuthController.sendOTPEmailPhone(paraData, (OTP) => {
                            const secretData = {secret: AuthenticationMiddleware.encodeData(OTP),
                                userId: idEncode, email: paraData.email};
                            resp.json({status: 200, message: 'User successfully created! OTP send to respected email',
                            data: AuthenticationMiddleware.encodeAuthToken(secretData)});
                        });
                    }, err => {
                        console.log(err);
                        resp.json({status: 500, message: 'Unable to create UserStatus!'});
                    });
                }, err => {
                    resp.json({ status: 500, message: (err.message === 'Validation error' ? 'User with email already exists!' : err.message) });
                });
            }
        });
    }

    /**
     * verifyOTP
     * @param req - will have body - otp,
     * use the headers x-request-id will contain the encrypted OTP and session
     */
    public verifyOTP(req: Request, resp: Response) {
        let paraData = req.body;
        if (paraData) {
            const now = moment().unix();
            // verify the otp duration
            if (now < paraData.exp) {
                // verify the otp
                if (CommonMiddleware.verifyOTP(paraData)) {
                    UserStatus.update({ verified: true },
                        { where: { userId: AuthenticationMiddleware.decodeData(paraData.userId) } }).then(result => {
                            // update user active status
                            Users.update({ isactive: true },
                                { where: { email: paraData.email } }).then(result => {
                                    resp.json({ status: 200, message: 'OTP verification done!' });
                                }, error => {
                                    resp.json({ status: 500, message: 'Internal Error', error: error.messageerror });
                                });
                        }, error => {
                            resp.json({ status: 500, message: 'Unable to update User status', error: error.messageerror });
                        })
                } else {
                    resp.json({ status: 500, message: 'Invalid OTP!' });
                }
            } else {
                resp.json({ status: 123, message: 'OTP expired' })
            }
        } else {
            resp.json({ status: 200, message: 'Ensure the request headers' });
        }
    }

    /**
     * resendOTP
     */
    public resendOTP(req: Request, resp: Response) {
        let paraData = req.body;
        if (paraData) {
            AuthController.sendOTPEmailPhone(paraData, (OTP) => {
                const secretData = {secret: AuthenticationMiddleware.encodeData(OTP),
                    userId: paraData.userId, email: paraData.email};
                resp.json({status: 200, message: 'OTP send to respected email',
                    data: AuthenticationMiddleware.encodeAuthToken(secretData)});
            });
        } else {
            resp.json({ status: 200, message: 'Ensure the request headers' });
        }
    }

    /**
     * generate captcha
     * @param req 
     * @param res - will be the captcha
     */
    public getCaptcha(req: Request, res: Response) {
        const randNum = CommonMiddleware.generateRandomNumber();
        var p = new captchapng(80, 30, randNum); // width,height,numeric captcha
        p.color(0, 0, 0, 0);  // First color: background (red, green, blue, alpha)
        p.color(80, 80, 80, 255); // Second color: paint (red, green, blue, alpha)

        var img = p.getBase64();
        var imgbase64 = new Buffer(img, 'base64');
        var valcode = new Buffer(imgbase64).toString('base64');
        res.json({ status: 200, captcha: valcode, value: randNum });
    }

    /**
     * forgotPassword
     * @param req - body will contain emailId
     */
    public forgotPassword(req: Request, resp: Response) {
        const paraData = req.body;
        if (paraData.email) {
            Users.findOne({ where: { email: paraData.email } }).then((U) => {
                if (U) {
                    Mailer.sendForgotMail(paraData.email, U.id, req.headers.origin, () => {
                        resp.json({ status: 200, message: 'Reset Password link send to respected mailId !!!' });
                    });
                } else {
                    resp.json({status: 500, message: 'Invalid User mailId !!!'});
                }                
            }, err => {
                resp.json({status: 500, message: 'Invalid User mailId !!!'});
            });
        } else {
            resp.json({ status: 500, message: 'Please send email as response body' });
        }
    }

    /**
     * resetPassword
     * @param req - body will contain the encrypted password
     */
    public resetPassword(req: Request, resp: Response) {
        const paraData = req.body;
        let userId = AuthenticationMiddleware.decodeData(req.query.q);
        Users.update({ password: paraData.password },
            { where: { id: userId } }).then(user => {
                resp.json({status: 200, message: 'Password reset done!'});
        }, err => {
            resp.json({status: 500, message: 'Unable to reset password, please retry!'})
        });
    }

    public otpCheck(req: Request, res, Response) {
        twillioClient.messages
            .create({
                body: 'Hi there! This is Twillio message integration',
                from: '+18635464071', to: '+447436161026'
            })
            .then(message => {
                console.log('message', message);
            }, err => {
                console.log('err', err);
            });
    }

    // ----------------------- End of request handlers

    /**
     * Mail send for OTP
     * @param paraData - email
     * @param callback - return the OTP
     */
    static sendOTPEmailPhone(paraData: any, fn: any) {
        let OTP = CommonMiddleware.generateRandomNumber();
        let text = 'Hi ' + OTP;
        Mailer.sendMail(paraData.email, text, 'otp', (status) => {
            console.log('status', status);
            return fn(OTP);
        });
    }
}

export const Controller = new AuthController();