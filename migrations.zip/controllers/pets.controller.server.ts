import { Request, Response } from 'express';
import MainDb from '../configs/sqls';
import Pet from '../models/pets.model.server'
const Sequelize = require('sequelize')

class PetsController {
    // ---------------------- Start of add pet
    addPet(req: any, resp: Response) {
        if (!req.body) {
            resp.status(422).send('Invalid request, Pet Id for edit is missing!');
        }
        let newP = Pet.build(req.body);
        newP.save().then(() => {
            resp.json({ status: 200, data: newP });
        }, err => {
            resp.json({ status: 500, message: 'Failed to add Pet, Please retry!' + err.message })
        });
    }

    // ---------------------- Start of Get all pets of Client
    getPetList(req: any, resp: Response) {
        if (req.body && !req.params.userId) {
            resp.status(422).send('Invalid request, required details are missing!');
            return;
        }
        const ofuserId = req.params.userId
        Pet.findAll({
            where: { userId: ofuserId }
        }).then((pets: any) => {
            resp.json({ status: 200, data: pets });
        }, err => {
            resp.json({ status: 500, message: 'Failed to retrieve Pets, please retry!' + err.message })
        });
    }

    // ---------------------- Start of edit pet
    editPet(req: any, resp: Response) {
        if (!req.params.petId) {
            resp.status(422).send('Invalid request, Pet Id for edit is missing!');
        }
        // get data from request object 
        let petId = req.params.petId;
        Pet.update(req.body, { where: { id: petId } })
            .then(
                () => {
                    resp.json({ status: 200, message: 'Pet Updated!' });
                }
                , (err) => {
                    resp.json({ status: 500, message: 'Failed to Update Pet, please retry! \n' + err.message });
                });
    }
    deletePet(req: any, resp: Response) {
        if (!req.params.petId) {
            resp.status(422).send('Invalid request, Pet Id for delete is missing!');
        }
        // get data from request object 
        Pet.destroy({ where: { id: req.params.petId } }, { force: true }).then(
            () => {
                resp.json({
                    'status': 200,
                    'message': 'Deleted Pet'
                });
            }, (err) => {
                resp.json({
                    'status': 500,
                    'message': 'Failed to delete Pet, please retry!'
                });
            });
    }
}

const controller = new PetsController();
export default controller;