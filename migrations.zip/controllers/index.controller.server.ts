import { Request, Response } from 'express';
import * as path from 'path';

class HomeController {
   public render(req: any, resp: Response): void {
      resp.sendFile(path.join(__dirname,'public', './index.html'));
   }
}

const controller =  new HomeController();
export default controller;