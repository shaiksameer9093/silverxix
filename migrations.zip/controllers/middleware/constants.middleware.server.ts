export class Constant {
    // link durations
    OTP_DURATION_MINUTE = 2;
    WITH_REMEMBER_ME_DAYS = 60;
    WITHOUT_REMEMBER_ME_DAYS = 1;
    RESET_DURATION_MINUTE = 10;
    REGISTRATION_DURATION_MINUTE = 10;

    // default text contents
    RESET_SUBJECT = 'Reset Password Invitation from Agkiya';
    REGISTRATION_SUBJECT = 'Invitation from Agkiya';
    CONFIRM_OTP_SUBJECT = 'OTP from Agkiya';

    // Twillio
    TWILLIO_ACCOUNTSID = 'ACae9d97de2fb0542f8a8d436e8dc44c36';
    TWILLIO_AUTHTOKEN = 'd64379e057b0fe6656269145567351f4';
    
}

const DefaultConstant = new Constant();
export default DefaultConstant;