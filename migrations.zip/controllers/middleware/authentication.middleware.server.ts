// load modules
import * as moment from 'moment';
import { encode, decode } from 'jwt-simple';
import { Request, Response, NextFunction } from 'express';
import * as CryptoJS from 'crypto-js';
const config = require('./../../configs/env/' + process.env.MEAN_ENV);

// -------- controllers import
import DefaultConstant from './constants.middleware.server';

const EXCEPTIONAL_LIST = ['/randomToken'];

class AuthMiddleware {
    
    constructor() { }

    /**
     * encodeToken - to encode the authorization using tokenObj and duration
     * @param tokenObj - will consists of one or more encoded objects
     * @param duration - will be the expiry time slot  
     */
    public encodeAuthToken(tokenObj: any, duration = 0) {
        let tokenDuration: any;
        switch (duration) {
            case 1:
                tokenDuration = moment().add(DefaultConstant.WITH_REMEMBER_ME_DAYS, 'd').unix();
                break;
            case 2:
                tokenDuration = moment().add(DefaultConstant.WITHOUT_REMEMBER_ME_DAYS, 'd').unix();
                break;
            case 3:
                tokenDuration = moment().add(DefaultConstant.RESET_DURATION_MINUTE, 'minutes').unix();
                break;
            default:
                tokenDuration = moment().add(DefaultConstant.OTP_DURATION_MINUTE, 'minutes').unix();
                break;
        }
        const payload = {
            exp: tokenDuration,
            iat: moment().unix(),
            sub: tokenObj
        };
        return Authentication.encodeData(payload);
    }

    /**
     * decodeToken - to decode the token
     * @param req - will have the body
     * @param resp - return the resonse
     * @param next - callback
     */
    public decodeToken(req: Request, resp: Response, next: NextFunction) {
        const token = req.body.token;
        const payload = Authentication.decodeData(token);
        const now = moment().unix();
        req.body.parse = Authentication.decodeData(token);
        if (now < payload.exp) {
            return next();
        } else {
            resp.json({
                status: 500,
                message: 'Token Expired'
            })
        }
    }

    /**
     * decode the authorization, while comparing the exceptional list
     * @param req 
     * @param resp 
     * @param next 
     */
    public decodeAuthToken(req: Request, resp: Response, next: NextFunction) {
        if (req.method !== 'OPTIONS') {
            // if the current requests are from the exceptional list or non authentication requests
            // ignore token verification and continue
            if (EXCEPTIONAL_LIST.indexOf(req.url) < 0) {
                const token = req.header('Authorization').slice(7);
                try {
                    const payload = Authentication.decodeData(token);
                    const now = moment().unix();
                    req.body.parse = payload;
                    if (now < payload.exp) {
                        return next();
                    } else {
                        resp.redirect('/login?redirectTo=' + req.url);
                    }
                } catch (error) {
                    resp.json({status: 401, message: 'Not Authorized'});
                }
            } else {
                return next();
            }
        } else {
            return next();
        }
    }

    /**
     * password encryption using AES algorithm
     * @param password to encrypt
     * @param secret set default secretKey / randomSalt
     */
    public passwordEncrypt(password, secret = ''): any {
        secret = (secret !== '' ? secret : config.secretKey);
        const key = CryptoJS.enc.Utf8.parse(secret);
        const iv = CryptoJS.enc.Utf8.parse('encryptionIntVec');
        const encrypted_password = CryptoJS.AES.encrypt(password, key, {
            keySize: secret.length,
            iv: iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        });
        return encrypted_password;
    }

    /**
     * password decryption using AES algorithm
     * @param password to decrypt
     * @param secret set default secretKey / randomSalt
     */
    public passwordDecrypt(password, secret = ''): any {
        secret = (secret !== '' ? secret : config.secretKey);
        const key = CryptoJS.enc.Utf8.parse(secret);
        const iv = CryptoJS.enc.Utf8.parse('encryptionIntVec');
        const decrypted_password = CryptoJS.AES.decrypt(password, key, {
            keySize: secret.length,
            iv: iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        });
        return decrypted_password;
    }

    /**
     * encodeData - to encode necessery data using secretkey
     * @param data
     */
    public encodeData(data): any {
        return encode(data, config.secretKey, 'HS512');
    }

    /**
     * decodeData - to decode necessery data using secretkey
     * @param data 
     */
    public decodeData(data: any) {
        return decode(data, config.secretKey, false, 'HS512');        
    }
}

const Authentication = new AuthMiddleware();
export default Authentication;