// load modules
import nodemailer = require('nodemailer');
const mailConfig = require(`../../configs/env/${process.env.MEAN_ENV}`).mailConfig;

// -------- controllers import
import Authentication from '../middleware/authentication.middleware.server';
import DefaultConstant from './constants.middleware.server';

// -------- setting up mail configuration
var transporter = nodemailer.createTransport(mailConfig.auth);
let mailOptions = {
    from: mailConfig.from, // sender address
    to: [], // list of receivers
    subject: DefaultConstant.REGISTRATION_SUBJECT, // Subject line
    html: '',
    
};

export default class Mailer {

    constructor() {}

    /**
     * sendForgotMail - to send mail with valid token
     * @param mailId - to send mail
     * @param userId - existing user id
     * @param host - the server hosted URI
     * @param fn - callback
     */
    static sendForgotMail(mailId: string, userId: any, host: any, fn: any) {
        let template: any;
        const token = Authentication.encodeAuthToken(Authentication.encodeData(userId), 3);
        const url = `${host}/auth/resetpassword?q=${token}`;
        const subject = DefaultConstant.RESET_SUBJECT;
        // template = restetemplate.replace('url', url);
        mailOptions.to = [mailId];
        mailOptions.subject = subject;
        mailOptions.html = 'Hi' + url;
        transporter.sendMail(mailOptions, (err: any, info: any) => {
            if (err) {
                console.log("mail" + err);
                fn();
            } else {
                fn();
            }
        });
    }

    /**
     * 
     * @param emails - array of email elements
     * @param data - 6 digits OTP
     * @param value - based on value data will appear in mail html ('otp', 'reset' - respectively)
     * @param callback - call when email send / fail
     */
    static sendMail(emails: any, data: any, value: any, callback: any) {
        let subject: any;
        const senderStatus = new Map<string, boolean>();
        let sentCount = 0;
        if (value === 'otp') {
            mailOptions.html = data;
            subject = DefaultConstant.CONFIRM_OTP_SUBJECT;
        } else if (value === 'reset') {
            mailOptions.html = data;
            subject = DefaultConstant.RESET_SUBJECT;
        } else {
            mailOptions.html = data;
            subject = DefaultConstant.REGISTRATION_SUBJECT;
        }
        // template = restetemplate.replace('url', url);
        mailOptions.to = [emails];
        mailOptions.subject = subject;
        transporter.sendMail(mailOptions, (err: any, info: any) => {
            if (err) {
                console.log(err);
                senderStatus.set(emails, false);
            } else {
                senderStatus.set(emails, true);
            }
            ++sentCount;
            if (sentCount > 0) {
                callback(senderStatus);
            }
        });
    }

    static generateInvitationContent(newP: any, bodyData: string, host: string) {
        const rHost = host;       
        const token = Authentication.encodeAuthToken(newP.id, DefaultConstant.REGISTRATION_DURATION_MINUTE);
        // reaplacing the selected content
        // bodyData = bodyData.replace(/{{first name}}/g, `${member.fName},`);
        // bodyData = bodyData.replace(/{{organization name}}/g, member.orgName);
        // bodyData = bodyData.replace(/<br>/g, '').replace(/<\/p><p>/g, '<br>');
        // bodyData +=`<br/>${LINK_CONTENT.replace('{{url}}',`${rHost}/#/login/${token}`)}`;
        // bodyData += `<br/>Thank You<br/>${member.orgName} Support Team<br/><br/>`;        
        // bodyData += FOOTER_CONTENT;
        return bodyData;
    }
}