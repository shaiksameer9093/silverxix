import AuthMiddleware from '../middleware/authentication.middleware.server';
import Authentication from '../middleware/authentication.middleware.server';
// For random numbers
export function generateRandomNumber(): number {
    return Math.floor(100000 + Math.random() * 900000);    
}

// For Encryption/hashing
export function getRandomSalt(): string {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

/**
 * verify the OTP and return boolean
 * @param secret - OTP
 * @param decodeOTP - OTP
 */
export function verifyOTP(otpData: any): boolean {
    if (otpData.otp === Authentication.decodeData(otpData.secret)) {
        return true;
    } else {
        return false;
    }
}