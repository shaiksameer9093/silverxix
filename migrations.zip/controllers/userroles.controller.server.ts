import { Request, Response } from 'express';
import MainDb from '../configs/sqls';


class UserrolesController {
    get(){
        
    }
}

const controller = new UserrolesController();
export default controller;