
-- Table Creation Query For Table users

CREATE TABLE `users` (
    `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `firstName` varchar(100) NOT NULL,
    `lastName` varchar(100) NULL,
    `password` varchar(500) NOT NULL,
    `email` varchar(250) NOT NULL,
    `gender` varchar(10) NOT NULL,
    `mobile` varchar(13) NOT NULL,
    `profilePic` varchar(150) NULL,
    `isactive` TINYINT NOT NULL DEFAULT 0,
    `lastAccessOn` datetime NULL,
    `createdOn` datetime NULL
 ) ENGINE=InnoDb AUTO_INCREMENT=1 DEFAULT CHARSET=utf8


