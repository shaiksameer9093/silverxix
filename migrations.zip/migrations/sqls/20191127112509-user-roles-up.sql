-- Table Creation Query For Table users Roles


CREATE TABLE `userroles` (
    `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `userId` int(11) NOT NULL,
    `roleId` int(11) NOT NULL,
    `createdOn` datetime NULL,
    `updatedOn`datetime NULL
 ) ENGINE=InnoDb AUTO_INCREMENT=1 DEFAULT CHARSET=utf8
