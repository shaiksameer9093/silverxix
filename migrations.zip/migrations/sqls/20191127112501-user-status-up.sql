
-- Table Creation Query For Table us

CREATE TABLE `userstatus` (
    `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `userId` int(11) NOT NULL,
    `verified` TINYINT NOT NULL DEFAULT 0,
    `verifiedOn` datetime NULL
 ) ENGINE=InnoDb AUTO_INCREMENT=1 DEFAULT CHARSET=utf8

