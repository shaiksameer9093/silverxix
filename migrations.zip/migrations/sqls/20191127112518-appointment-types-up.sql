-- Table Creation Query For Table Appointment Types

CREATE TABLE `appointment_types` (
    `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `typeName` varchar(50) NOT NULL
 ) ENGINE=InnoDb AUTO_INCREMENT=1 DEFAULT CHARSET=utf8
