-- Table Creation Query For Table Appointments

CREATE TABLE `appointments` (
    `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `userId` int(11) NOT NULL,
    `petId` int(11) NOT NULL,
    `bookingId` varchar(50) NOT NULL,
    `appointmentDate` datetime NOT NULL,
    `slot` datetime NOT NULL,
    `appointmentTypeId` datetime NULL,
    `paymentId`  varchar(100) NOT NULL,
    `status`  varchar(50) NOT NULL,
    `userRating` INT(1) NULL,
    `practiceRating` INT(1) NULL,
    `createdOn` datetime NULL
 ) ENGINE=InnoDb AUTO_INCREMENT=1 DEFAULT CHARSET=utf8


  