
-- Table Creation Query For Table Pets

CREATE TABLE `pets` (
    `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `userId` int(11) NOT NULL,
    `petName` varchar(150) NOT NULL,
    `breed` varchar(100) NOT NULL,
    `species` varchar(100) NOT NULL,
    `gender` varchar(50) NOT NULL,
    `dob` date NULL,
    `profilePic` varchar(100) NULL,
    `updatedOn` datetime NULL,
    `createdOn` datetime NULL
 ) ENGINE=InnoDb AUTO_INCREMENT=1 DEFAULT CHARSET=utf8

   