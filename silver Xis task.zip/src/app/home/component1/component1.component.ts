import { Component, OnInit } from '@angular/core';
import { actions } from '../component1/actions';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
@Component({
  selector: 'app-component1',
  templateUrl: './component1.component.html',
  styleUrls: ['./component1.component.scss']
})
export class Component1Component implements OnInit {
  public actionData = actions;
  dropdownList = [];
  selectedItems = [];
  dropdownSettings:IDropdownSettings;
  public IDropdownSettings:any;
  public selectedAction:any
  showActionattributes = false;
  showTable = false;
  public header = []
  constructor() { 
  }
  ngOnInit(){}
  attributeSelect(){
    this.dropdownList = [
      { item_id: 1, item_text: 'Charges' },
      { item_id: 2, item_text: 'Directions' },
      { item_id: 3, item_text: 'Equipment' },
      { item_id: 4, item_text: 'Exclusion' },
      { item_id: 5, item_text: 'Expertise' },
      { item_id: 6, item_text: 'Material List' }
    ];
    this.selectedItems = [];
    this.dropdownSettings ={
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
    };
  }
  selectAction(){
    this.showActionattributes = true
    this.attributeSelect();
  }
  onItemSelect(item: any) {
    const selectValue = item.item_text
    this.header = selectValue;
  }
  onSelectAll(items: any) {
    const selectValue = items.item_text
    this.header = selectValue;
  }
  addTable(){
    this.showTable =true
  }
}
